def bad_code(x):
    if x == True:
        return 1
    else:
        return 0
