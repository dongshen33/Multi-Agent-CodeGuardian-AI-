# CodeGuardian AI

Multi-Agent AI system for automated code review and fixing.

## Features
- Multi-agent architecture
- Automatic bug detection
- AI-powered code fixing
- Validation pipeline

## Run

pip install -r requirements.txt
python main.py
