from utils.llm import ask_llm

def fix_code(code):
    prompt = f"""
    Fix the issues in the following code and return improved version:
    {code}
    """
    return ask_llm(prompt)
