def validate(original, fixed):
    if original != fixed:
        return "Fix applied successfully"
    return "No change"
