import os

def scan_code(directory):
    code_files = []
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(".py"):
                path = os.path.join(root, file)
                with open(path, "r", encoding="utf-8") as f:
                    code_files.append((path, f.read()))
    return code_files
