from utils.llm import ask_llm

def analyze_code(code):
    prompt = f"""
    Analyze the following code and find potential issues:
    {code}
    Return structured JSON.
    """
    return ask_llm(prompt)
