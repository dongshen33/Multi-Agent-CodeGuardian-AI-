from agents.scanner import scan_code
from agents.analyzer import analyze_code
from agents.fixer import fix_code
from agents.validator import validate

def run_pipeline(path):
    files = scan_code(path)

    for file_path, code in files:
        print(f"\nProcessing: {file_path}")

        analysis = analyze_code(code)
        print("Analysis:", analysis)

        fixed_code = fix_code(code)
        result = validate(code, fixed_code)

        print("Validation:", result)
